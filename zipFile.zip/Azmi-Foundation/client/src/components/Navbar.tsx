import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Menu, X, Heart, User } from "lucide-react";
import { useState } from "react";
import {
  DropdownMenu,
  DropdownMenuContent,
  DropdownMenuItem,
  DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";

export function Navbar() {
  const [isOpen, setIsOpen] = useState(false);
  const [location] = useLocation();
  const { user, logout } = useAuth();

  const links = [
    { href: "/", label: "Home" },
    { href: "/about", label: "About Us" },
    { href: "/programs", label: "Programs" },
    { href: "/campaigns", label: "Campaigns" },
    { href: "/get-involved", label: "Get Involved" },
  ];

  const isActive = (path: string) => location === path;

  return (
    <nav className="sticky top-0 z-50 w-full bg-white/95 backdrop-blur-md border-b border-gray-100 shadow-sm transition-all duration-300">
      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
        <div className="flex justify-between h-20">
          <div className="flex items-center">
            <Link href="/" className="flex-shrink-0 flex items-center gap-2 cursor-pointer group">
              <div className="w-10 h-10 bg-secondary rounded-lg flex items-center justify-center group-hover:bg-secondary/90 transition-colors">
                <Heart className="w-6 h-6 text-white fill-current" />
              </div>
              <span className="text-2xl font-bold font-serif text-primary">
                Azmi<span className="text-secondary">Foundation</span>
              </span>
            </Link>
          </div>

          {/* Desktop Menu */}
          <div className="hidden md:flex items-center space-x-8">
            {links.map((link) => (
              <Link key={link.href} href={link.href} className={`
                text-sm font-medium transition-colors duration-200 cursor-pointer relative py-2
                ${isActive(link.href) ? 'text-secondary' : 'text-gray-600 hover:text-secondary'}
              `}>
                {link.label}
                {isActive(link.href) && (
                  <span className="absolute bottom-0 left-0 w-full h-0.5 bg-secondary rounded-full" />
                )}
              </Link>
            ))}
            
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <Button variant="ghost" className="relative h-10 w-10 rounded-full overflow-hidden border border-gray-200">
                     {user.profileImageUrl ? (
                       <img src={user.profileImageUrl} alt={user.firstName || 'User'} className="h-full w-full object-cover" />
                     ) : (
                       <User className="h-5 w-5 text-gray-500" />
                     )}
                  </Button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-48">
                   <Link href="/dashboard">
                     <DropdownMenuItem className="cursor-pointer">Dashboard</DropdownMenuItem>
                   </Link>
                   <DropdownMenuItem onClick={() => logout()} className="cursor-pointer text-red-500">
                     Logout
                   </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <a href="/api/login">
                <Button variant="outline" className="border-primary text-primary hover:bg-primary hover:text-white transition-all">
                  Sign In
                </Button>
              </a>
            )}

            <Link href="/donate">
              <Button className="bg-secondary hover:bg-secondary/90 text-white font-semibold shadow-lg shadow-secondary/25 hover:shadow-xl hover:-translate-y-0.5 transition-all duration-300 rounded-full px-6">
                Donate Now
              </Button>
            </Link>
          </div>

          {/* Mobile menu button */}
          <div className="flex items-center md:hidden">
            <button
              onClick={() => setIsOpen(!isOpen)}
              className="inline-flex items-center justify-center p-2 rounded-md text-gray-400 hover:text-gray-500 hover:bg-gray-100 focus:outline-none focus:ring-2 focus:ring-inset focus:ring-secondary"
            >
              {isOpen ? <X className="block h-6 w-6" /> : <Menu className="block h-6 w-6" />}
            </button>
          </div>
        </div>
      </div>

      {/* Mobile Menu */}
      {isOpen && (
        <div className="md:hidden bg-white border-t border-gray-100 animate-in slide-in-from-top-5 duration-300">
          <div className="px-2 pt-2 pb-3 space-y-1 sm:px-3">
            {links.map((link) => (
              <Link key={link.href} href={link.href}>
                <div 
                  className={`block px-3 py-2 rounded-md text-base font-medium cursor-pointer ${
                    isActive(link.href) 
                      ? 'bg-secondary/10 text-secondary' 
                      : 'text-gray-600 hover:text-secondary hover:bg-gray-50'
                  }`}
                  onClick={() => setIsOpen(false)}
                >
                  {link.label}
                </div>
              </Link>
            ))}
            {!user && (
              <a href="/api/login" className="block w-full">
                <Button variant="outline" className="w-full mt-4">Sign In</Button>
              </a>
            )}
            <Link href="/donate">
              <Button className="w-full mt-2 bg-secondary text-white">Donate Now</Button>
            </Link>
          </div>
        </div>
      )}
    </nav>
  );
}
